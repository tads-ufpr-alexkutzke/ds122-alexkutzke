# Ponto de partida da aula de JavaScript

DS122 - Desenvolvimento de Aplicações Web 1, Prof. Alexander Robert Kutzke.

Estes arquivos são o estado em que a página fica **ao final da aula de layout com
CSS**, e é deles que parte a aula
[JavaScript: sintaxe moderna (ES6+)](https://tads-ufpr-alexkutzke.github.io/ds122-alexkutzke/aula_06_00_js.html).

Use este pacote se você não tem em mãos o seu próprio `index.html`,
`catalogo.html`, `contato.html` e `css/estilo.css`. Quem tem os próprios arquivos
trabalha neles, não aqui.

## Conteúdo

```
index.html          página inicial, com conteúdo e barra lateral
catalogo.html       seis cartões de produto, em grade
contato.html        formulário estilizado
css/estilo.css      folha única, ligada nas três páginas, com o layout pronto
imagens/produto.svg imagem de exemplo usada pelos cartões
```

Não há pasta `js/`: criá-la é o primeiro passo da parte prática.

Os nomes dos produtos são reais, para que a busca por texto tenha o que
encontrar. As descrições são *lorem ipsum*, o texto de preenchimento que a
diagramação usa há séculos para ocupar espaço sem dizer nada.

## Como usar

1. Descompacte a pasta em qualquer lugar do seu computador, preservando a
   estrutura de diretórios: `css/` e `imagens/` precisam ficar ao lado dos
   arquivos `.html`;
2. Abra o `catalogo.html` no navegador com dois cliques;
3. Aperte `F12` e vá para a aba **Console**;
4. Siga a parte prática da aula a partir da seção 15.

Não é preciso servidor: são arquivos estáticos, abertos direto do disco. Scripts
comuns funcionam assim; apenas `<script type="module">` exigiria um servidor
HTTP, e nenhum exercício desta aula usa módulos.

## O que já está pronto e o que falta

A folha de estilo cobre as duas aulas de CSS: `box-sizing`, tipografia, cores com
contraste conferido, `:focus-visible`, modelo de caixa dos cartões, formulário,
rodapé, e ainda o cabeçalho em Flexbox, a grade do catálogo em Grid e uma *media
query* em 768px.

Não há **nenhuma** linha de JavaScript, e nenhuma tag `<script>` ativa. No
`<head>` do `catalogo.html` existe um comentário mostrando onde as duas tags
entram na seção 15 da aula.

Cada cartão de `catalogo.html` traz nome, categoria e preço visíveis. São esses
os valores que você vai repetir no array de `js/produtos.js`, na seção 16: o
array e o HTML descrevem os mesmos seis produtos, e manter os dois iguais é o que
permite, na aula seguinte, gerar os cartões a partir do array.

## Isto não é a Entrega 2 do trabalho prático

Estas páginas existem para o exercício da aula. Reaproveitá-las como entrega do
trabalho não funciona, por três motivos:

1. **O ramo de produtos é escolha sua**, com preferência por temas de viés
   sustentável. Catálogo entregue ainda com a Loja Exemplo e com *lorem ipsum* no
   lugar da descrição conta como requisito não cumprido;
2. **O catálogo do trabalho pede ao menos oito produtos**, e aqui há seis. Falta
   também a `sobre.html` e a seção de destaque da página inicial, exigidas desde
   a Entrega 1;
3. **A Entrega 2 pede o filtro ligado à página**, com os campos de busca e de
   faixa de preço alterando os cartões na tela. O que se faz aqui roda no
   console, e é a metade anterior do caminho.

Além disso, a Prova 2 traz uma questão sobre o seu próprio projeto, em que você
modifica ou explica o código entregue. Código de terceiros na entrega aparece
ali.
