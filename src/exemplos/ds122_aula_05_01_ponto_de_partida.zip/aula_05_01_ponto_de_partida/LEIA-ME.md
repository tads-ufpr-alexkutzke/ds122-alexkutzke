# Ponto de partida da aula de layout com CSS

DS122 - Desenvolvimento de Aplicações Web 1, Prof. Alexander Robert Kutzke.

Estes arquivos são o estado em que a página fica **ao final da tarefa de CSS
(fundamentos)**, e é deles que parte a aula
[CSS3: layout e responsividade](https://tads-ufpr-alexkutzke.github.io/ds122-alexkutzke/aula_05_01_css_layout.html).

Use este pacote se você não tem em mãos o seu próprio `index.html`,
`catalogo.html`, `contato.html` e `css/estilo.css` da tarefa anterior. Quem tem
os próprios arquivos trabalha neles, não aqui.

## Conteúdo

```
index.html          página inicial, com conteúdo e barra lateral
catalogo.html       três cartões de produto, empilhados
contato.html        formulário estilizado
css/estilo.css      folha única, ligada nas três páginas
imagens/produto.svg imagem de exemplo usada pelos cartões
```

Os produtos se chamam "Produto 1", "Produto 2" e "Produto 3", e todo o texto
corrido é *lorem ipsum*, o texto de preenchimento que a diagramação usa há
séculos para ocupar espaço sem dizer nada. Isso é de propósito: o pacote serve
para você ver o layout mudar, e o conteúdo é você quem escreve. Ficam em
português apenas o menu, os rótulos e os botões do formulário, que precisam
continuar compreensíveis para quem preenche a página.

## Como usar

1. Descompacte a pasta em qualquer lugar do seu computador, preservando a
   estrutura de diretórios: `css/` e `imagens/` precisam ficar ao lado dos
   arquivos `.html`;
2. Abra o `catalogo.html` no navegador com dois cliques;
3. Siga a parte prática da aula a partir da seção 11.

Não é preciso servidor: são arquivos estáticos, abertos direto do disco.

## O que já está pronto e o que falta

A folha de estilo cobre só o que foi visto na aula de fundamentos: `box-sizing`,
tipografia base, cores com contraste conferido, cabeçalho, menu com `hover` e
`:focus-visible`, modelo de caixa dos cartões, formulário e rodapé.

Não há **nenhuma** regra de `display: flex`, `display: grid` ou `@media`. Por
isso o menu fica na vertical e os cartões empilham um debaixo do outro. Esse é o
estado descrito na seção 1 da aula, e é o que a aula vai mudar.

Dois pontos preparados para a parte prática:

- os três cartões de `catalogo.html` estão dentro de um `<div class="grade">`,
  com o `<h2>Produtos</h2>` fora dele. O contêiner já existe, e o que falta é a
  regra `.grade` na folha, que você escreve na seção 12. O título fica de fora
  de propósito: os itens de um contêiner são os filhos diretos, e o `h2`
  passaria a ocupar espaço na linha junto com os cartões;
- as três páginas têm um `<main class="conteudo">` com uma `<aside
  class="lateral">`, que é o alvo da *media query* da seção 14.

## Isto não é a Entrega 1 do trabalho prático

Estas páginas existem para o exercício da aula. Reaproveitá-las como Entrega 1
não funciona, por três motivos:

1. **O ramo de produtos é escolha sua**, com preferência por temas de viés
   sustentável. Catálogo entregue ainda com a Loja Exemplo, com "Produto 1" e
   com *lorem ipsum* no lugar da descrição conta como requisito não cumprido;
2. **O catálogo da Entrega 1 pede ao menos oito produtos**, e aqui há três;
3. **Faltam a `sobre.html` e a seção de destaque com três produtos na página
   inicial**, ambas exigidas no enunciado.

Além disso, a prova seguinte traz uma questão sobre o seu próprio projeto, em
que você modifica ou explica o código entregue. Código de terceiros na entrega
aparece ali.

Se quiser aproveitar a folha de estilo como referência, leia-a, entenda cada
regra e escreva a sua. Copiar o arquivo inteiro deixa a Entrega 1 sem o item
*Design e usabilidade* e sem parte do item *Qualidade do código*, que valem
juntos 35% da nota do trabalho.
